<?php

namespace App\Http\Controllers;

use App\Setting;
use App\Snippet;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    protected $request;
    protected $setting;
    protected $snippet;

    public function __construct() {
        $this->request = app(Request::class);
        $this->setting = app(Setting::class);
        $this->snippet = app(Snippet::class);
    }

    public function changeTheme() {

        if (settings(true)->theme == $this->request->theme) {
            exit("same");
        }

        $this->updateSetting('theme', $this->request->theme);

        return ucwords($this->request->theme);
    }

    public function changeThemeType() {

        if (settings(true)->theme_type == $this->request->type) {
            exit("same");
        }

        $this->updateSetting('theme_type', $this->request->type);

        return ($this->request->type);
    }

    public function keepLastCodes() {
        $this->updateSetting('keep_last_codes', $this->request->keep_codes);
        $this->snippet = $this->snippet->orderBy('updated_at', 'desc')->first();

        return response()->json([
            'status' => $this->request->keep_codes,
            'contents' => htmlspecialchars_decode($this->snippet->contents),
            'snippet' => $this->snippet
        ]);
    }

    public function updateSetting($index, $value) {
        $this->setting = $this->setting->all();
        $settings = json_decode($this->setting[0]->settings);

        $settings->$index = $value;
        $this->setting[0]->settings = json_encode($settings);

        return $this->setting[0]->save();
    }

    public function checkUpdates() {
        dd($this->request);
    }

    public function getSettings() {
        return json_decode($this->setting->first()->settings);
    }


}
