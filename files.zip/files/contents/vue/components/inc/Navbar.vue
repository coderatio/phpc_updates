<template>
    <div>
        <ul id="dropdown1" class="dropdown-content">
            <li><a href="#shortcodesModal" class="modal-trigger"><i class="material-icons left">code</i> Shortcodes</a></li>
            <li><a href="#helpModal" class="modal-trigger"><i class="material-icons left">help</i> Help</a></li>
            <li class="divider"></li>
            <li><a href="https://github.com/coderatio/phpconsole" target="_blank"><i class="material-icons left">exit_to_app</i> Contribute</a></li>
        </ul>
        <nav>
            <div class="nav-wrapper">
                <a href="#!" class="brand-logo left">v0.0.2</a>
                <ul class="right hide-on-small-only">
                    <!--<router-link to="/code" tag="li">-->
                        <!--<a><i class="material-icons left">code</i> Code</a>-->
                    <!--</router-link>-->
                    <!--<router-link to="/preview" tag="li">-->
                        <!--<a><i class="material-icons left">visibility</i> Preview</a>-->
                    <!--</router-link>-->
                    <li><a href="" class="dropdown-trigger" data-target="dropdown1"><i class="material-icons">more_vert</i></a></li>
                </ul>
            </div>
        </nav>
    </div>
</template>

<script>
    export default {
        name: "Navbar"
    }
</script>

<style scoped>
    .brand-logo {
        margin-left: 25px;
        font-size: 14px;
        font-weight: normal;
        color: #666;
    }
    #helpModal.modal {
        width: 35% !important;
    }
</style>