<?php
/**
 * Created by PhpStorm.
 * User: JOSIAH
 * Date: 4/28/2018
 * Time: 6:13 PM
 */

echo "This is a demo controller";