<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;

class EvaluationController extends Controller
{
    protected $request;

    public function __construct(Request $request) {
        $this->request = $request;
    }

    /**
     * @return mixed
     * @throws Exception
     */
    public function evaluate() {
        $contents = $this->request->contents;

        $checkStartTag = str_contains($contents, ['<?php']);

        if (!$checkStartTag) {
            throw new Exception("You must start with php open tag.");
        }

        $contents = str_replace('<?php', '', $contents);
        $contents = str_replace('?>', '', $contents);

        if ($contents == '') {
            $contents = "You've not started coding yet";
        }

        return eval(trim($contents));
    }
}
