<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PHP Console</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="{{ asset('vendors/animate.css') }}">
    {{--<link rel="stylesheet" href="{{ asset('vendors/jquery.mCustomScrollbar/jquery.mCustomScrollbar.min.css') }}">--}}
    <link rel="stylesheet" href="{{ asset('css/font.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body class="{{ settings(true)->theme_type }} {{ settings(true)->theme }}">
<div id="app">
    <Navbar></Navbar>
    <div class="row">
        <div class="col s3">
            <div class="sidebar-wrap">
                <div class="sidebar-inner" data-simplebar data-simplebar-auto-hide="false">
                    <div class="center-align" style="margin-bottom: 30px;">
                        {{--<div class="profile">--}}
                            {{--<img src="{{ asset('img/logo-white.png') }}" alt="Logo" class="app-logo"/>--}}
                        {{--</div>--}}
                        <h5 class="left-align"><i>PHP</i> Console</h5><br/>
                    </div>
                    <div class="input-field col s12">
                        <br/>
                        <select class="select" id="themeType" name="theme_type">
                            <option value="" disabled selected>Change theme</option>
                            <option value="dark-theme" @if(settings(true)->theme_type == 'dark-theme') selected @endif>Dark theme</option>
                            <option value="light-theme" @if(settings(true)->theme_type == 'light-theme') selected @endif>Light theme</option>
                        </select>
                        <label for="">Theme</label>
                    </div>

                    <div class="input-field col s12">
                        <br/>
                        <select class="select" id="changeTheme" name="theme">
                            <option value="" disabled selected>Change color scheme</option>
                            <option value="tomorrow_night_bright" @if(settings(true)->theme == 'tomorrow_night_bright') selected @endif>Coder Black</option>
                            <option value="chrome" @if(settings(true)->theme == 'chrome') selected @endif>Coder Light</option>
                        </select>
                        <label for="">Color Scheme</label>
                    </div>

                    <div class="input-field col s12">
                        <p>LOAD LAST CODES</p>
                        <div class="switch">
                            <label>
                                No
                                <input type="checkbox" value="yes" id="keepLastCodes" @if(settings(true)->keep_last_codes == 'yes') checked @endif >
                                <span class="lever"></span>
                                Yes
                            </label>
                        </div>
                    </div>
                    <Sidebar></Sidebar>
                </div>
            </div>
        </div>
        <div class="col s9">
            <div class="content-wrap">
                {{--<textarea v-bind="contents" id="contents" name="editor" rows="1" cols="1"></textarea>--}}
                <ul id="phpcTabs" class="tabs tabs-fixed-width blue-grey darken-4">
                    <li class="tab col s8"></li>
                    <li class="tab col s2"><a href="#codes" class="" id="coder">Code</a></li>
                    <li class="tab col s2"><a href="#preview" id="showPreview" class="">Execute</a></li>
                </ul>
                <div id="codes">
                    <div class="content-codes">
                        <div class="content-inner z-depth- animated fadeIn" id="editor"></div>
                    </div>
                </div>
                <div id="preview">
                    <div class="content-inner z-depth-2 white" style="z-index: 2;">
                        <div id="codesPreview" style="padding: 20px;" class="animated fadeIn"></div>
                    </div>
                </div>
                <router-view></router-view>
            </div>
        </div>
    </div>
</div>
<div id="blockModal" class="modal" style="width: 25% !important;">
    <div class="modal-content center-align">
        <div class="preloader-wrapper active">
            <div class="spinner-layer spinner-blue">
                <div class="circle-clipper left">
                    <div class="circle"></div>
                </div>
                <div class="gap-patch">
                    <div class="circle"></div>
                </div>
                <div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
            </div>
        </div>
        <div id="blockModalContent"></div>
    </div>
</div>
@include('modals')
<div class="fixed-action-btn">
    <a class="btn-floating waves-effect waves-light updateSnippet saveCodes btn-large red">
        <i class="large material-icons">save</i>
    </a>
</div>
<div class="open-snippets" style="right: 100px; bottom: 25px; position:absolute;">
    <a href="#snippetsModal" class="btn modal-trigger purple waves-effect waves-light btn-large" id="openSnippetsModal">
        <i class="large material-icons left">code</i> Snippets
    </a>
</div>
<input type="hidden" name="active_snippet" value="" id="activeSnippet">
<script src="{{ asset('vendors/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ asset('vendors/blockui.js') }}"></script>
{{--<script src="{{ asset('vendors/jquery.mCustomScrollbar/jquery.mCustomScrollbar.min.js') }}"></script>--}}
<script src="{{ asset('vendors/keyboardJS/keyboard.min.js') }}"></script>
<script>
    const AppUrl = '{{ url('/') }}';
    const AppSettings = $.parseJSON({!! settings() !!});
</script>

<script src="{{ asset('vendors/ace/emmet-compiled.js') }}"></script>
<script src="{{ asset('vendors/ace/src/ace.js') }}"></script>
<script src="{{ asset('vendors/ace/src/ext-emmet.js') }}"></script>
<script src="{{ asset('vendors/ace/src/ext-language_tools.js') }}"></script>
<!-- load ace static_highlight extension -->
<script src="{{ asset('vendors/ace/src/ext-static_highlight.js') }}"></script>

<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
