$(document).ready(function () {
    $('#phpcTabs').tabs();
    $('.modal').modal();
    $('.select').formSelect();
    $('.fixed-action-btn').floatingActionButton();
    $('.tooltipped').tooltip();
    $('.sidenav').sidenav();


});

(function ($) {
    $.fn.setCursorToTextEnd = function () {
        this.focus();
        let initialVal = this.val();
        this.val('').val(initialVal);

        return this;
    }
}(jQuery));

// (function($){
//     $(window).on("load",function(){
//
//         $(".sidebar-inne").mCustomScrollbar({
//             theme:"minimal-dark"
//         });
//
//         $(".content-").mCustomScrollbar({
//             setHeight: 300,
//             theme:"minimal-dark"
//         });
//
//     });
// })(jQuery);

/**
 * Editor
 */

let activeTheme = AppSettings.theme;


let Editor = ace.edit("editor", {
    theme: "ace/theme/" + activeTheme,
    mode: "ace/mode/php",
    enableEmmet: true,
    showPrintMargin: false,
    enableBasicAutocompletion: true,
    fontSize: 14,
    fontFamily: 'Consolas',
    enableLiveAutocompletion: true,
    enableSnippets: true,
    selectionStyle: "line",
    cursorStyle: "smooth-slim",
    scrollPastEnd: false,
    tooltipFollowsMouse: true,
    newLineMode: 'windows',
    foldStyle: 'markbeginend',
    wrap: true,
    tabSize: 4
});
let editorCodes = Editor.getSession().getValue();
let startValue = "<";
startValue += "?php\n\n";
startValue += "//Start coding here\n\n";
Editor.setValue(startValue, 1);
Editor.focus();

// Make editor focus when code tab is clicked
$('#coder').click(() => {
    Editor.focus();
});


/**
 *
 * @param message
 * @param extra
 * @returns {*}
 */

function toast(message, extra='') {
    if (extra !== '') {
        extra = `<button class="btn-flat toast-action">${extra}</button>`;
    }
    let toastHTML = `<span><i class="material-icons left">check</i> ${message}</span>${extra}`;
    return M.toast({html: toastHTML, classes: 'pc-toast', displayLength: 3000});
}

function toastError(message, extra='') {
    if (extra !== '') {
        extra = `<button class="btn-flat toast-action">${extra}</button>`;
    }
    let toastHTML = `<span><i class="material-icons left">error_outline</i> ${message}</span>${extra}`;
    return M.toast({html: toastHTML, classes: 'pc-toast-error', displayLength: 3000});
}

function blockModal(message) {
    let elem = document.querySelector('#blockModal');
    let instance = M.Modal.init(elem, {
        dismissible: false
    });
    instance.open();
    $('#blockModalContent').html(message);
}

function unblockModal() {
    $('#blockModal').modal('close');
}

function closeAlertBlockable(element = '') {
    $('#closeAlertBlockable').click(function (e) {
        if (element === '') {
            $.unblockUI();
        } else {
            $(element).unblock();
        }
        e.preventDefault();
    });
}

/**
 * Snippet vars
 */


let snippetNameInput = $('#snippetName');
let snippetsHolder = $('#snippetsHolder');
let snippetNameHolder = $('#snippetNameHolder');
let dynamicTitle = $('#dynamicTitle');
let snippetContents = Editor.getSession().getValue();
snippetNameHolder.hide();

/**
 * Add new snippet
 */

function initiateAddSnippet() {
    snippetsHolder.hide();
    snippetNameHolder.show();
    dynamicTitle.html('New Snippet');
    $('.add-snippet').hide('slow');
    snippetNameInput.focus();

    $('#cancelAddSnippet').click(function () {
        snippetsHolder.show();
        snippetNameHolder.hide();
        dynamicTitle.html('Your Snippets');
        $('#nameError').html('');
        $('.add-snippet').show();
    });
}
function addSnippet() {

    $('.add-snippet').click((e) => {
        initiateAddSnippet();
        e.preventDefault();
    });

    /**
     * Save snippet
     */

    snippetNameInput.on('input', function (e) {
        if ($(this).val() === '') {
            $('#nameError').html('Enter snippet name');
            return false;
        } else {
            $('#nameError').html('');
        }
    });

    $('#saveSnippet').click(function(e){
        if (snippetNameInput.val() === '') {
            $('#nameError').html('Enter snippet name.');
            snippetNameInput.focus();
            return false;
        } else {
            $('#nameError').html('');
        }

        snippetsHolder.html('');

        saveSnippet();

        e.preventDefault();
    });
}

/**
 * Update snippet
 * @returns {boolean}
 */
function updateSnippet() {
    blockModal("Saving snippet");
    let codesInEditor = Editor.getSession().getValue();
    let activeSnippet = $('#activeSnippet').val();
    if (activeSnippet === '') {
        unblockModal();
        toastError("No snippet selected. Save this as new snippet rather.");
        Editor.focus();
        return false;
    }

    axios.post('/snippets/update', {id: activeSnippet, contents: codesInEditor})
        .then(response => {
            unblockModal();
            loadAllSnippets();
            toast("Snippet updated");
        })
        .catch(error => console.log(error))
}

/**
 * Store added snippet
 */
function saveSnippet() {
    let snippetSource = $('#snippetSource').val();
    let snippetContents = '<';
    if (snippetSource === 'blank' || snippetSource === null) {
        snippetContents += '?php\n\n';
        snippetContents += '//Start coding here';
    }

    if (snippetSource === 'editor') {
        snippetContents = Editor.getSession().getValue();
    }

    blockModal('Adding Snippet');
    axios.post('/snippets/add', {
        name: snippetNameInput.val(),
        contents: snippetContents
    }).then(response => {
        unblockModal();
        snippetNameInput.val('');
        let valueToSet = "&lt;?php";
        valueToSet += response.data.contents;
        snippetNameHolder.hide();
        snippetsHolder.show();
        dynamicTitle.html('Your Snippets');
        $('.add-snippet').show('slow');
        $('div').removeClass('code');
        snippetsHolder.prepend(`
            <div class="col m3">
            <a href="" class="load" id="${response.data.id}">
            <div class="card black">
            <div class="card-image">
            <a href="" class="editSnippet snippet-action-btn btn-small halfway-fab blue-grey darken-3 btn-floating waves-effect waves-light" id="${response.data.id}" title="Edit"><i class="material-icons left">edit</i></a>
            <a href="" class="saveEditedSnippet hiddendiv snippet-action-btn btn-small halfway-fab purple darken-3 btn-floating waves-effect waves-light" id="${response.data.id}" title="Save"><i class="material-icons left">check</i></a>
            <a href="" class="deleteSnippet snippet-action-btn btn-small halfway-fab grey darken-3 btn-floating waves-effect waves-light" id="${response.data.id}" title="Delete"><i class="material-icons left">delete_forever</i></a>
            <a href="" class="cancelEditingSnippet hiddendiv snippet-action-btn btn-small halfway-fab red btn-floating waves-effect waves-light" id="${response.data.id}" title="Close"><i class="material-icons left">close</i></a>
            </div>
            <div class="card-content">
            <div class="code" id="new-code${response.data.id}" ace-mode="ace/mode/php" ace-theme="ace/theme/tomorrow_night_bright" ace-gutter="true" style="height: 130px; !important; display: block; max-height: 130px; min-height: 130px">
${valueToSet}
            </div>
            </div>
            <div class="card-action" id="snippetAction-${response.data.id}">
                <div class="truncate snippet-card-action-inner" id="${response.data.id}">
                <div class="input-field hiddendiv" id="${response.data.id}">
                <input type="text" name="edit_snippet_name" id="editSnippetName-${response.data.id}" class="snippetEditInput white-text" value="${response.data.name}">
                </div>
                <a href="#" class="load" id="${response.data.id}">${response.data.name}</a>
                </div>
            </div>
            </div>
            </a>
            </div>
            `);
        activateHighlighter();
        editSnippet();
        deleteSnippet();
        loadSnippetInEditor(response.data.id);

    }).catch(error => console.log(error.response));
}

function loadSnippetInEditor(id, notFocus = false) {
    blockModal('Loading Snippet');
    axios.post('/snippets/load-in-editor', {snippetId: id})
        .then(response => {
            unblockModal();
            $('#activeSnippet').val(id);
            $('#snippetsModal').modal('close');
            let snippet = '<';
            snippet += '?php';
            if (response.data.snippet === '') {
                snippet += '\n\n//Start coding here\n\n';
            } else {
                snippet += response.data.snippet + '\n\n';
            }

            Editor.setValue(snippet, 1);
            if (!notFocus) {
                Editor.focus();
            }
        })
        .catch(error => console.log(error.response));
}

function loadAllSnippets() {
    axios.post('/snippets/show')
        .then(response => {
            let newSnippets = '';

            if (response.data.all_snippets.length > 0) {
                response.data.all_snippets.forEach(function (snippet) {
                    newSnippets += `
               <div class="col m3">
        <div class="card black z-depth-2">
        <div class="card-image">
        <a href="" class="editSnippet snippet-action-btn btn-small halfway-fab blue-grey darken-3 btn-floating waves-effect waves-light" id="${snippet.id}" title="Edit"><i class="material-icons left">edit</i></a>
        <a href="" class="saveEditedSnippet hiddendiv snippet-action-btn btn-small halfway-fab purple darken-3 btn-floating waves-effect waves-light" id="${snippet.id}" title="Save"><i class="material-icons left">check</i></a>
        <a href="" class="deleteSnippet snippet-action-btn btn-small halfway-fab grey darken-3 btn-floating waves-effect waves-light" id="${snippet.id}" title="Delete"><i class="material-icons left">delete_forever</i></a>
        <a href="" class="cancelEditingSnippet hiddendiv snippet-action-btn btn-small halfway-fab red btn-floating waves-effect waves-light" id="${snippet.id}" title="Close"><i class="material-icons left">close</i></a>
        </div>
         <a href="" class="load" id="${snippet.id}">
            <div class="card-content">
                <div class="code" id="snippetCode" ace-mode="ace/mode/php" ace-theme="ace/theme/tomorrow_night_bright" 
                ace-gutter="true">
&lt;?php ${snippet.contents}
                </div>
        </div>
        </a>
        <div class="card-action" id="snippetAction-${snippet.id}">
            <div class="truncate snippet-card-action-inner" id="${snippet.id}">
            <div class="input-field hiddendiv" id="${snippet.id}">
            <input type="text" name="edit_snippet_name" id="editSnippetName-${snippet.id}" class="snippetEditInput white-text" value="${snippet.name}">
            </div>
            <a href="#" class="load" id="${snippet.id}">${snippet.name}</a>
            </div>
        </div>
    </div>
</div>   
               `;
                });
                snippetsHolder.html(newSnippets);
                activateHighlighter();
                editSnippet();
                deleteSnippet();
                $('.load').click(function (e) {
                    loadSnippetInEditor(this.id);
                    e.preventDefault();
                });

            } else {
                snippetsHolder.html(`<div class="col m6 offset-m3">
                        <div class="card grey darken-4" id="noSnippetCard">
                            <div class="card-content center-align">
                                <h6>No snippets found</h6><br/><br/>
                                <a href="" class="btn purple darken-2 add-snippet" id="addSnippet"><i class="material-icons left">add</i> Create Now</a>
                            </div>
                        </div>
                    </div>
                `);

                addSnippet();
            }

        })
        .catch(error => {

        });
}

//Snippets highlighter
let highlight = ace.require("ace/ext/static_highlight");
let dom = ace.require("ace/lib/dom");
function qsa(sel) {
    return Array.apply(null, document.querySelectorAll(sel));
}

function activateHighlighter() {
    qsa(".code").forEach(function (codeEl) {
        highlight(codeEl, {
            mode: codeEl.getAttribute("ace-mode"),
            theme: codeEl.getAttribute("ace-theme"),
            startLineNumber: 1,
            showGutter: codeEl.getAttribute("ace-gutter"),
            trim: true,
            wrap: false,
            fontSize: 14,
            fontFamily: 'Consolas',
        }, function (highlighted) {

        });
    });
}

function getLastSnippet() {
    axios.post('/get-codes')
        .then(response => {
            unblockModal();
            if (response.data !== 'not-allowed') {
                let codes = '<';
                codes += '?php';
                if (response.data.codes === '') {
                    codes += '\n\n//Start coding here\n\n';
                } else {
                    codes += response.data.codes + '\n\n';
                }
                Editor.setValue(codes, 1);
                Editor.focus();
                $('#activeSnippet').val(response.data.id)
            } else {
                toastError("Loading last codes disabled.");
            }
        });
}

function editSnippet() {
    $('.editSnippet').click(function (e) {
        let snippetId = this.id;
        let This = $(this);
        let cardAction = $('.card-action#snippetAction-'+snippetId);
        let cardBtnHolder = $('.card-image');
        let actionInput = cardAction.find('input#editSnippetName-'+snippetId);
        let actionInputField = cardAction.find('div.input-field#'+snippetId);
        let snippetNameWrapper = cardAction.find(`a.load#${snippetId}`);
        let saveBtn = cardBtnHolder.find('a.saveEditedSnippet#'+snippetId);
        let closeBtn = cardBtnHolder.find('a.cancelEditingSnippet#'+snippetId);
        let deleteBtn = cardBtnHolder.find('a.deleteSnippet#'+snippetId);

        cardAction.find('.snippet-card-action-inner').addClass('active');
        cardAction.addClass('has-input');
        saveBtn.removeClass('hiddendiv');
        This.hide();
        deleteBtn.hide();
        closeBtn.removeClass('hiddendiv');
        actionInputField.removeClass('hiddendiv');
        snippetNameWrapper.hide();
        actionInput.setCursorToTextEnd();

        function save() {
            axios.post('/snippets/update-name', {id: snippetId, name: actionInput.val()})
                .then(response => {
                    let snippet = response.data;
                    snippetNameWrapper.html(snippet.name);
                    unblockModal();
                })
                .catch(error => console.log(error.response));
        }

        keyboardJS.bind('enter', function (e) {
            blockModal('Saving');
            actionInput.setCursorToTextEnd();
            save();
        });

        /**
         * Save edited snippet name
         */
        saveBtn.click(function (e) {
            blockModal('Saving');
            actionInput.setCursorToTextEnd();

            save();
            e.preventDefault();
        });

        /**
         * Close snippet editing
         */

        function closeEditing() {
            cardAction.find('.snippet-card-action-inner').removeClass('active');
            cardAction.removeClass('has-input');
            saveBtn.addClass('hiddendiv');
            This.show();
            deleteBtn.show();
            closeBtn.addClass('hiddendiv');
            actionInputField.addClass('hiddendiv');
            snippetNameWrapper.show();
        }

        keyboardJS.bind('ctrl + q', function (e) {
            closeEditing();
        });

        closeBtn.click(function (e) {
            closeEditing();
            e.preventDefault();
        });

        e.preventDefault();
    });
}

function deleteSnippet() {
    let deleteBtn = $('.deleteSnippet');
    deleteBtn.click(function (e) {
        let snippetId = this.id;
        let alertDialog = $('#alertBlockable');
        let element = $('#snippetsModal');
        element.block({ message: alertDialog});

        let yesDelete = $('.yesDelete');
        yesDelete.attr('id', snippetId);

       yesDelete.click(function (e) {
           let id = yesDelete.attr('id');
           blockModal('Deleting');
           axios.post('/snippets/delete', {id: id})
               .then(response => {
                   let activeSnippet = $('#activeSnippet');
                   if (response.data.id.toString() === activeSnippet.val()) {
                       activeSnippet.val('');
                       let snippet = '<';
                       snippet += '?php\n\n';
                       snippet += '//Start coding here\n\n';
                       Editor.setValue(snippet, 1);
                       Editor.focus();
                   }

                   element.unblock();
                   unblockModal();
                   loadAllSnippets();
               })
               .catch(error => console.log(error.response));
           e.preventDefault();
       });

        keyboardJS.bind('ctrl + q', function (e) {
            $('#snippetsModal').unblock();
        });

        closeAlertBlockable('#snippetsModal');

        e.preventDefault();
    });
}

function saveEditedSnippetName(id, name) {
    let saveBtn = $('.card-image').find('a.saveEditedSnippet#'+snippetId);

    saveBtn.click(function (e) {
        blockModal('Please wait');
        axios.post('/snippets/update-name', {id: id, name: name})
            .then(response => {
                unblockModal();
                console.log(response.data);
            })
            .catch(error => console.log(error.response));

        e.preventDefault();
    });

}

deleteSnippet();
activateHighlighter();


let previewHolder = $('#codesPreview');
let message = 'Please wait..';
let preLoader = `
        <div style="margin-top: 20%; display: block; text-align: center;">
            <div class="preloader-wrapper small animated fadeIn active">
                <div class="spinner-layer spinner-blue-only">
                  <div class="circle-clipper left">
                    <div class="circle"></div>
                  </div><div class="gap-patch">
                    <div class="circle"></div>
                  </div><div class="circle-clipper right">
                    <div class="circle"></div>
                  </div>
                </div>
            </div>
            <div style="margin-left: 10px; text-align: center" id="message">Loading your preview...</div>
        </div>
    `;

previewHolder.html(preLoader);

Editor.getSession().on('change', function(){

});


//Show preview
$('#showPreview').click(function (e) {

    let contents = Editor.getSession().getValue();
    previewHolder.removeClass('has-errors');
    previewHolder.html(preLoader);

    if (startValue === contents) {
        return previewHolder.html("You've not started coding yet!").addClass('has-errors');
    }

    axios.post('/get-preview', {contents: contents})
        .then(response => {
            let result = response.data;
            if (typeof result === 'object') {
                previewHolder.addClass('has-errors');
                return previewHolder.html(`${result.message}`);
            }else {
                previewHolder.removeClass('has-errors');
            }
            previewHolder.html(`${result}`);
        })
        .catch(error => {
            console.log(error);
        });

    e.preventDefault();
});

/**
 * Color scheme, shortcodes and Saving last codes
 */
$(document).ready(function () {
    const themeType = $('#themeType');
    const changeTheme = $('#changeTheme');

    themeType.change(() => {
        blockModal("Activating...");
        let selectedValue = themeType.val();

        /**
         * Change theme type (dark or light)
         */
        axios.post('/change-theme-type', {type: selectedValue})
            .then(response => {
                unblockModal();
                $('body').removeClass('light-theme dark-theme').addClass(selectedValue);
                if (response.data !== 'same') {
                    toast(`Theme set successfully`);
                } else {
                    toast(`Already active`);
                }

                Editor.focus();
            })
            .catch(error => console.log(error));
    });

    /**
     * Change editor color scheme theme.
     */
    changeTheme.change(() => {
        blockModal("Please wait...");
        let selectedValue = changeTheme.val();
        axios.post('/change-theme', {theme: selectedValue})
            .then(response => {
                unblockModal();
                Editor.setTheme("ace/theme/" + selectedValue);

                if (response.data !== 'same') {
                    toast(`Colour scheme set successfully`);
                } else {
                    toast(`Already active`);
                }

                Editor.focus();
            })
            .catch(error => console.log(error));
    });

    const keepLastCodes = $('#keepLastCodes');
    keepLastCodes.click(() => {
        blockModal("Saving...");
        let checkedValue = 'no';
        if(keepLastCodes.is(':checked')) {
            checkedValue = 'yes';
        }

        axios.post('/keep-last-codes', {keep_codes: checkedValue})
            .then(response => {
                unblockModal();
                let codes = '<';
                codes += '?php';

                if (response.data.status === 'yes') {
                    codes += response.data.contents;
                    $('#activeSnippet').val(response.data.snippet.id);
                    toast("Load last codes enabled.");
                } else {
                    codes += "\n\n//Start coding here\n";
                    toast("Load last codes disabled.");
                }

                Editor.setValue(codes+'\n', 1);
                Editor.focus();
            })
            .catch(error => console.log(error))
    });

    //Recursively check if keeping last codes in memory
    $('.updateSnippet').on('click', function() {
        updateSnippet();
    });

    /** Load last written codes into editor */
    blockModal("Initializing...");

    getLastSnippet();

    //Force editor to be focus
    Editor.focus();

    //Key Bindings
    //Open snippets modal
    keyboardJS.bind('ctrl + o', function(e) {
        $('#snippetsModal').modal('open');
    });
    //Add snippet command
    keyboardJS.bind('ctrl + n', function(e) {
        $('#snippetsModal').modal('open');
        initiateAddSnippet();
    });
    //SHow help modal
    keyboardJS.bind('alt + h', function(e) {
        $('#helpModal').modal('open');
    });
    Editor.commands.addCommand({
        name: 'showHelpCommand',
        bindKey: {win: 'Alt-H',  mac: 'Alt-H'},
        exec: function(editor) {
            $('#helpModal').modal('open');
        },
        readOnly: true // false if this command should not apply in readOnly mode
    });

    //Save current editor codes to memory
    keyboardJS.bind('ctrl + enter', function (e) {
        updateSnippet();
    });
    keyboardJS.bind('ctrl + s', function (e) {
        updateSnippet();
    });
    Editor.commands.addCommand({
        name: 'saveCodesCommand',
        bindKey: {win: 'Ctrl-ENTER',  mac: 'Command-ENTER'},
        exec: function(editor) {
            updateSnippet();
        },
        readOnly: true // false if this command should not apply in readOnly mode
    });

    Editor.commands.addCommand({
        name: 'saveCodesCommand',
        bindKey: {win: 'Ctrl-S',  mac: 'Command-S'},
        exec: function(editor) {
            updateSnippet();
        },
        readOnly: false // false if this command should not apply in readOnly mode
    });

    //Show keyboard shortcuts
    keyboardJS.bind('ctrl + k', function (e) {
        $('#shortcodesModal').modal('open');
    });
    Editor.commands.addCommand({
        name: 'showShortcutsCommand',
        bindKey: {win: 'Ctrl-K',  mac: 'command-K'},
        exec: function(editor) {
            $('#shortcodesModal').modal('open');
        },
        readOnly: true // false if this command should not apply in readOnly mode
    });

    /** New Snippet */

    /**
     * Add snippet
     */
    addSnippet();

    /**
     * Load all snippets
     */
    loadAllSnippets();

    /**
     * Load snippets on modal open
     */

    $('#openSnippetsModal').click(function () {
        loadAllSnippets();
    });


});

$files = [
    {
        files: ['demo.php', 'demo2.php'],
        remote_url: 'github.com/coderatio/phpconsole/updates/controllers',
        local_path: 'app/http/controllers'
    },
    {
        files: [''],
        remote_url: ''
    }
];

$update = {
    old_version: '0.0.1',
    new_version: '0.0.2'
};






