<?php

namespace App\Http\Controllers;

use App\PhpC\UpdatesManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UpdatesController extends Controller
{
    protected $storage;
    protected $request;
    protected $app;
    protected $manager;
    protected $error;
    protected $message;
    protected $versions = [];

    public function __construct() {
        $this->storage = app(Storage::class);
        $this->request = app(Request::class);
        $this->app = settings(true);
        $this->manager = app(UpdatesManager::class);
    }

    public function checkUpdates() {
        return view('check-updates');
    }

    public function autoCheckUpdates() {
        set_time_limit(0);
        $this->message = null;
        $this->error = null;
        $this->versions = [
            'installed' => $this->app->version,
            'available' => ''
        ];

        try {
            if (isConnected()) {
                if ($this->storage::disk('updates')->exists('check.json')) {
                    $this->storage::disk('updates')->delete('check.json');
                }
                $url = "https://raw.githubusercontent.com/coderatio/phpc_updates/master/check.json";
                copy($url, storage_path('app/updates/check.json'));
                $contents = file_get_contents(storage_path('app/updates/check.json'));
                $checker = json_decode($contents);
                if ($checker->current == $this->app->version) {
                    $this->message = "You have the latest version.";
                } elseif ($checker->current > $this->app->version) {
                    $this->message = "New version is available. <br/><br/><a href='".url('download-updates')."' class='btn purple'>Update Now</a>";
                }
                $this->versions['available'] = $checker->current;
                $this->storage::disk('updates')->delete('check.json');
            } else {
                $this->error = 'No Internet';
            }
        } catch (\Exception $e) {
            $this->error = $e->getMessage();
        }

        return response()->json([
            'message' => $this->message,
            'error' => $this->error,
            'versions' => $this->versions
        ]);
    }
}
