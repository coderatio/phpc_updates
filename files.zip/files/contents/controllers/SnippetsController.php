<?php

namespace App\Http\Controllers;

use App\Snippet;
use Illuminate\Http\Request;

class SnippetsController extends Controller {

    protected $request;
    protected $snippet;

    public function __construct(Request $request, Snippet $snippet) {
        $this->request = $request;
        $this->snippet = $snippet;
    }

    public function store() {

        $contents = htmlspecialchars(str_replace('<?php', '', $this->request->contents));

        $this->snippet->name = $this->request->name;
        $this->snippet->contents = $contents;
        $this->snippet->save();

        return response()->json([
            'id' => $this->snippet->id,
            'contents' => $contents,
            'name' => $this->snippet->name
        ]);
    }

    public function show() {
        $this->snippet = $this->snippet->orderBy('id', 'desc')->get();
        $html = '';
        $snippets = '';
        foreach($this->snippet as $snippet) {
            $snippets .= $snippet->contents;
            $html .= '
        <div class="col m3">
    <a href="" class="load" id="' . $snippet->id . '">
        <div class="card black">
        <div class="card-image">
        <a href="" class="editSnippet snippet-action-btn btn-small halfway-fab blue-grey darken-3 btn-floating waves-effect waves-light" id="' . $snippet->id . '" title="Edit"><i class="material-icons left">edit</i></a>
        <a href="" class="saveEditedSnippet hiddendiv snippet-action-btn btn-small halfway-fab purple darken-3 btn-floating waves-effect waves-light" id="' . $snippet->id . '" title="Save"><i class="material-icons left">check</i></a>
        <a href="" class="deleteSnippet snippet-action-btn btn-small halfway-fab grey darken-3 btn-floating waves-effect waves-light" id="' . $snippet->id . '" title="Delete"><i class="material-icons left">delete_forever</i></a>
        <a href="" class="cancelEditingSnippet hiddendiv snippet-action-btn btn-small halfway-fab red btn-floating waves-effect waves-light" id="' . $snippet->id . '" title="Close"><i class="material-icons left">close</i></a>
        </div>
            <div class="card-content">
                <div class="code" id="snippetCode" ace-mode="ace/mode/php" ace-theme="ace/theme/tomorrow_night_bright" 
                ace-gutter="false" style="display: block; height: 100px; overflow: hidden">
&lt;?php\n' .$snippet->contents . '
            </div>
        </div>
        <div class="card-action" id="snippetAction-'.$snippet->id.'">
            <div class="truncate snippet-card-action-inner" id="'.$snippet->id.'">
            <div class="input-field hiddendiv" id="'.$snippet->id.'">
            <input type="text" name="edit_snippet_name" id="editSnippetName-'.$snippet->id.'" class="snippetEditInput white-text" value="'.$snippet->name.'">
            </div>
            <a href="#" class="load" id="'.$snippet->id.'">'.$snippet->name.'</a>
            </div>
        </div>
    </div>
</a>
</div>
        ';
        }

        return response()->json([
            'html' => trim($html),
            'all_snippets' => $this->snippet,
            'snippets' => $snippets
        ]);
    }

    public function loadInEditor() {
        $this->snippet = $this->snippet->find($this->request->snippetId);
        if (!$this->snippet) {
            return response()->json([
                'id' => 0,
                'snippet' => '',
            ]);
        }
        $this->snippet->updated_at = now();
        $this->snippet->save();
        $snippet = htmlspecialchars_decode($this->snippet->contents);

        return response()->json([
            'id' => $this->snippet->id,
            'snippet' => str_replace_last('\n\n', '\n\n', $snippet)
        ]);
    }

    public function update() {
        $this->snippet = $this->snippet->find($this->request->id);
        $dateTime = date('d-m-y H:i:s A');
        $lastSaved = "\n\n/** Last Saved {$dateTime} */";
        $snippet = str_replace('<?php', '', "{$this->request->contents}");
        $this->snippet->contents = htmlspecialchars($snippet);
        $this->snippet->updated_at = now();
        $this->snippet->save();

        return response()->json([
            'id' => $this->snippet->id,
            'contents' => str_replace_first(' ', '', $this->snippet->contents),
        ]);
    }

    public function updateName() {
        $this->snippet = $this->snippet->find($this->request->id);
        $this->snippet->name = $this->request->name;
        $this->snippet->save();

        return response()->json($this->snippet);
    }

    public function destroy() {
        $this->snippet = $this->snippet->whereId($this->request->id)->first();

        try {
            $response = $this->snippet;
            $this->snippet->delete();
        } catch (\Exception $e) {
            $response = $e;
        }

        return response()->json($this->snippet);
    }
}
